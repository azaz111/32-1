#!/bin/bash
cd /disk4/video1
sleep 3
q=1
while [ $q -le 5 ]
do
echo "Tak"
sleep 3 
 for f in *plot; do
   echo "$(stat -c  %s "$f")"
   if [ $(stat -c %s "$f" | bc) -gt 108650979224 ]
   then
   sleep 15
   X=${f//plot-k32/video}
   mv -- "$f" "/disk4/video1/${X%.plot}.db"
   echo "PERENOS"
   fi
   done
done    
  

